package com.example.ecommerce_product.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.concurrent.CompletableFuture;

import org.springframework.http.ResponseEntity;

@Entity
@Table(name = "PRODUCT")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "PRODUCT_ID")
    private Long product_id;

    @Column(name = "PRODUCT_NAME")
    private String product_name;

    @Column(name = "PRODUCT_PRICE")
    private double product_price;

    @Column(name = "PRODUCT_SPECIAL_PRICE")
    private double product_special_price;

    @Column(name = "PRODUCT_QUANTITY")
    private int product_quantity;

    @Column(name = "PRODUCT_DISCOUNT")
    private double product_discount;

    @Column(name = "PRODUCT_IMAGE")
    private String product_image;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "PRODUCT_CATEGORY")
    private String product_category;

    @Column(name = "CREATED_DATE")
    private LocalDateTime createdDate;

    @Column(name = "UPDATED_DATE")
    private LocalDateTime updatedDate;

    // Getters and Setters

    public Long getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Long product_id) {
        this.product_id = product_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public double getProduct_price() {
        return product_price;
    }

    public void setProduct_price(double product_price) {
        this.product_price = product_price;
    }

    public double getProduct_special_price() {
        return product_special_price;
    }

    public void setProduct_special_price(double product_special_price) {
        this.product_special_price = product_special_price;
    }

    public int getProduct_quantity() {
        return product_quantity;
    }

    public void setProduct_quantity(int product_quantity) {
        this.product_quantity = product_quantity;
    }

    public double getProduct_discount() {
        return product_discount;
    }

    public void setProduct_discount(double product_discount) {
        this.product_discount = product_discount;
    }

    public String getProduct_image() {
        return product_image;
    }

    public void setProduct_image(String product_image) {
        this.product_image = product_image;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getProduct_category() {
        return product_category;
    }

    public void setProduct_category(String product_category) {
        this.product_category = product_category;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

	public CompletableFuture<ResponseEntity<? extends Object>> thenCompose(Object object) {
		return null;
	}



}
