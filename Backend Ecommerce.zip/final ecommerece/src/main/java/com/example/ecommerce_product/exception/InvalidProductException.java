package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class InvalidProductException extends RuntimeException {
    public InvalidProductException(String message) {
        super(message);
    }
}
