package com.example.ecommerce_product.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

@Entity
@Table(name = "wishlist_item")
public class WishlistItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ITEM_ID")
    private Long itemId;

    @ManyToOne
    @JsonIgnore // Avoid serialization issues with User
    @JoinColumn(name = "USER_ID", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "PRODUCT_ID", nullable = false)
    private Product product;

    @ManyToOne
    @JoinColumn(name = "CATEGORY_ID")
    private WishlistCategory category;

    // Default constructor
    public WishlistItem() {
    }

    // Parameterized constructor
    public WishlistItem(User user, Product product, WishlistCategory category) {
        this.user = user;
        this.product = product;
        this.category = category;
    }

    // Getters and setters
    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public WishlistCategory getCategory() {
        return category;
    }

    public void setCategory(WishlistCategory category) {
        this.category = category;
    }

    @Override
    public String toString() {
        return "WishlistItem [itemId=" + itemId + ", user=" + user + ", product=" + product + ", category=" + category + "]";
    }
}
