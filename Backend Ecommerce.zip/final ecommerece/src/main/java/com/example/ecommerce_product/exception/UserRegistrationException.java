package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class UserRegistrationException extends RuntimeException {
    public UserRegistrationException(String message) {
        super(message);
    }
}
