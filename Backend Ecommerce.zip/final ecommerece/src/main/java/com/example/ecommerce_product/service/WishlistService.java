package com.example.ecommerce_product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ecommerce_product.entity.Product;
import com.example.ecommerce_product.entity.User;
import com.example.ecommerce_product.entity.WishlistItem;
import com.example.ecommerce_product.exception.ProductNotFoundException;
import com.example.ecommerce_product.exception.UserNotFoundException;
import com.example.ecommerce_product.exception.WishlistNotFoundException;
import com.example.ecommerce_product.repository.ProductRepository;
import com.example.ecommerce_product.repository.UserRepository;
import com.example.ecommerce_product.repository.WishlistRepository;

@Service
public class WishlistService {

    @Autowired
    private WishlistRepository wishlistRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ProductRepository productRepository;

    @Async
    @Transactional
    @CacheEvict(value = "wishlistCache", allEntries = true)
    public void addProductToWishlist(Long userId, Long productId) {
        validateIds(userId, productId);

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + productId));

        WishlistItem item = new WishlistItem();
        item.setUser(user);
        item.setProduct(product);

        wishlistRepository.save(item);
    }

    @Cacheable(value = "wishlistCache", key = "'user_' + #userId + '_wishlist'")
    public List<WishlistItem> getWishlistItemsByUser(Long userId) {
        if (userId == null) {
            throw new IllegalArgumentException("User ID must be provided");
        }

        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + userId));

        return wishlistRepository.findByUser(user);
    }

    @Async
    @Transactional
    @CacheEvict(value = "wishlistCache", allEntries = true)
    public boolean removeFromWishlist(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Wishlist item ID must be provided");
        }

        if (!wishlistRepository.existsById(id)) {
            throw new WishlistNotFoundException("Wishlist item with ID " + id + " not found.");
        }

        wishlistRepository.deleteById(id);
        return true;
    }

    private void validateIds(Long userId, Long productId) {
        if (userId == null || productId == null) {
            throw new IllegalArgumentException("User ID and Product ID must be provided");
        }
    }

	public List<WishlistItem> getWishlistItemsByUserAndCategory(Long userId, String categoryName) {
		return null;
	}
}
