package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class UserAuthenticationException extends RuntimeException {
    public UserAuthenticationException(String message) {
        super(message);
    }
}
