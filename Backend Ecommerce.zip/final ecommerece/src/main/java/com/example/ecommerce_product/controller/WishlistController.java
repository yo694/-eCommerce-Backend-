package com.example.ecommerce_product.controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce_product.entity.WishlistItem;
import com.example.ecommerce_product.exception.ProductNotFoundException;
import com.example.ecommerce_product.exception.UserNotFoundException;
import com.example.ecommerce_product.exception.WishlistNotFoundException;
import com.example.ecommerce_product.service.WishlistService;

@RestController
@RequestMapping("/api/wishlist")
public class WishlistController {

    private static final Logger logger = LoggerFactory.getLogger(WishlistController.class);

    @Autowired
    private WishlistService wishlistService;

    @GetMapping
    public ResponseEntity<List<WishlistItem>> getAllWishlistItems(@RequestParam Long userId) {
        logger.debug("Fetching all wishlist items for user ID {}.", userId);
        try {
            List<WishlistItem> wishlistItems = wishlistService.getWishlistItemsByUser(userId);
            if (wishlistItems.isEmpty()) {
                logger.info("No wishlist items found for user ID {}.", userId);
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(wishlistItems);
        } catch (UserNotFoundException e) {
            logger.warn("User not found: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
            logger.error("Error occurred while fetching wishlist items: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping
    public ResponseEntity<Void> addToWishlist(@RequestParam Long userId, @RequestParam Long productId) {
        logger.debug("Adding product with ID {} to wishlist for user ID {}.", productId, userId);
        try {
            wishlistService.addProductToWishlist(userId, productId);
            logger.info("Product with ID {} added to wishlist for user ID {} successfully.", productId, userId);
            return ResponseEntity.status(HttpStatus.CREATED).build();
        } catch (ProductNotFoundException | UserNotFoundException e) {
            logger.warn("Failed to add product to wishlist: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
            logger.error("Error occurred while adding product to wishlist: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> removeFromWishlist(@PathVariable Long id) {
        logger.debug("Removing wishlist item with ID {}.", id);
        try {
            if (wishlistService.removeFromWishlist(id)) {
                logger.info("Wishlist item with ID {} removed successfully.", id);
                return ResponseEntity.noContent().build();
            } else {
                logger.warn("Wishlist item with ID {} not found.", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
        } catch (WishlistNotFoundException e) {
            logger.warn("Failed to remove wishlist item: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
            logger.error("Error occurred while removing wishlist item with ID {}: {}", id, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/category")
    public ResponseEntity<List<WishlistItem>> getWishlistItemsByCategory(
            @RequestParam Long userId, 
            @RequestParam String categoryName) {
        logger.debug("Fetching all wishlist items for user ID {} and category {}.", userId, categoryName);
        try {
            List<WishlistItem> wishlistItems = wishlistService.getWishlistItemsByUserAndCategory(userId, categoryName);
            if (wishlistItems.isEmpty()) {
                logger.info("No wishlist items found for user ID {} and category {}.", userId, categoryName);
                return ResponseEntity.noContent().build();
            }
            return ResponseEntity.ok(wishlistItems);
        } catch (Exception e) {
            logger.error("Error occurred while fetching wishlist items by category: {}", e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
