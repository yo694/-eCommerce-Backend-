package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class WishlistItemValidationException extends RuntimeException {
    public WishlistItemValidationException(String message) {
        super(message);
    }
}
