package com.example.ecommerce_product.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ecommerce_product.entity.User;
import com.example.ecommerce_product.entity.WishlistCategory;
import com.example.ecommerce_product.entity.WishlistItem;

@Repository
public interface WishlistRepository extends JpaRepository<WishlistItem, Long> {
    List<WishlistItem> findByUser(User user);
    List<WishlistItem> findByUserAndCategory(User user, WishlistCategory category);
}
