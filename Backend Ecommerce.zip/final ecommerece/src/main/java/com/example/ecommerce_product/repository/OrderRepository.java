package com.example.ecommerce_product.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ecommerce_product.entity.Orders;

public interface OrderRepository extends JpaRepository<Orders, Long> {
}
