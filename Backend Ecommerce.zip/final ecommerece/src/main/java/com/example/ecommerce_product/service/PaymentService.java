package com.example.ecommerce_product.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ecommerce_product.entity.Payment;
import com.example.ecommerce_product.exception.PaymentNotFoundException;
import com.example.ecommerce_product.repository.PaymentRepository;

import java.util.concurrent.CompletableFuture;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Async
    @Transactional
    @CacheEvict(value = "paymentsCache", allEntries = true) // Evict all entries when a payment is created
    public CompletableFuture<Payment> createPayment(Long orderId, Double amount) {
        if (orderId == null || amount == null || amount <= 0) {
            throw new IllegalArgumentException("Order ID and amount must be provided and amount must be positive");
        }
        
        Payment payment = new Payment();
        payment.setOrderId(orderId);
        payment.setAmount(amount);
        payment.setPaymentDate(LocalDateTime.now());
        payment.setStatus("Completed");
        
        Payment savedPayment = paymentRepository.save(payment);
        return CompletableFuture.completedFuture(savedPayment);
    }

    @Cacheable(value = "paymentsCache", key = "#id")
    public Payment getPaymentById(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Payment ID must be provided");
        }
        return paymentRepository.findById(id)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found with ID: " + id));
    }
}
