package com.example.ecommerce_product.service;

import com.example.ecommerce_product.entity.Product;
import com.example.ecommerce_product.exception.InvalidProductException;
import com.example.ecommerce_product.exception.ProductNotFoundException;
import com.example.ecommerce_product.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Service
public class ProductService {

    private static final Logger logger = LoggerFactory.getLogger(ProductService.class);

    @Autowired
    private ProductRepository productRepository;

    @Cacheable(value = "productsCache", key = "'allProducts'")
    public List<Product> getAllProducts() {
        logger.debug("Fetching all products.");
        List<Product> products = productRepository.findAll();
        logger.info("Retrieved {} products.", products.size());
        return products;
    }

    @Cacheable(value = "productsCache", key = "#id")
    public CompletableFuture<Product> getProductById(Long id) {
        logger.debug("Fetching product with ID {}.", id);
        return CompletableFuture.supplyAsync(() -> 
            productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product not found with ID: " + id))
        );
    }

    @Async
    @Transactional
    @CacheEvict(value = "productsCache", allEntries = true)
    public CompletableFuture<Product> addProduct(Product product) {
        validateProduct(product);
        logger.debug("Adding product: {}", product);
        Product savedProduct = productRepository.save(product);
        logger.info("Product added with ID {}.", savedProduct.getProduct_id());
        return CompletableFuture.completedFuture(savedProduct);
    }

    @Async
    @Transactional
    @CacheEvict(value = "productsCache", key = "#id")
    public CompletableFuture<Product> updateProduct(Long id, Product product) {
        if (!productRepository.existsById(id)) {
            logger.warn("Product with ID {} not found for update.", id);
            throw new ProductNotFoundException("Product not found with ID: " + id);
        }
        product.setProduct_id(id);
        validateProduct(product);
        logger.debug("Updating product with ID {}: {}", id, product);
        Product updatedProduct = productRepository.save(product);
        logger.info("Product with ID {} updated successfully.", id);
        return CompletableFuture.completedFuture(updatedProduct);
    }

    @Async
    @Transactional
    @CacheEvict(value = "productsCache", key = "#id")
    public CompletableFuture<Void> deleteProduct(Long id) {
        if (!productRepository.existsById(id)) {
            logger.warn("Product with ID {} not found for deletion.", id);
            throw new ProductNotFoundException("Product not found with ID: " + id);
        }
        logger.debug("Deleting product with ID {}.", id);
        productRepository.deleteById(id);
        logger.info("Product with ID {} deleted successfully.", id);
        return CompletableFuture.completedFuture(null);
    }

    private void validateProduct(Product product) {
        if (product.getProduct_name() == null || product.getProduct_name().isEmpty()) {
            logger.error("Validation failed: Product name cannot be null or empty.");
            throw new InvalidProductException("Product name cannot be null or empty");
        }
        if (product.getProduct_price() <= 0) {
            logger.error("Validation failed: Product price must be greater than zero.");
            throw new InvalidProductException("Product price must be greater than zero");
        }
        if (product.getProduct_quantity() < 0) {
            logger.error("Validation failed: Product quantity cannot be negative.");
            throw new InvalidProductException("Product quantity cannot be negative");
        }
    }
}
