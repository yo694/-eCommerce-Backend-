package com.example.ecommerce_product.service;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import com.example.ecommerce_product.entity.Cart;
import com.example.ecommerce_product.exception.CartOperationException;
import com.example.ecommerce_product.repository.CartRepository;
@Service
public class CartService {
    private static final Logger logger = LoggerFactory.getLogger(CartService.class);
    @Autowired
    private CartRepository cartRepository;

    @Cacheable(value = "cartItemsCache", key = "'allCartItems'")
    public List<Cart> getAllCartItems() {
        logger.debug("Fetching all cart items from the database.");
        List<Cart> cartItems = cartRepository.findAll();
        if (cartItems.isEmpty()) {
            logger.info("No cart items found.");
        } else {
            logger.info("Retrieved {} cart items.", cartItems.size());
        }
        return cartItems;
    }

    public CompletableFuture<List<Cart>> getAllCartItemsAsync() {
        return CompletableFuture.completedFuture(getAllCartItems());
    }

    @CachePut(value = "cartItemCache", key = "#cart.cart_id")
    public Cart addToCart(Cart cart) {
        logger.debug("Adding cart item with product ID {} and quantity {}.", cart.getProduct().getProduct_id(), cart.getQuantity());
        Cart savedCart = cartRepository.save(cart);
        logger.info("Cart item added successfully. Cart ID: {}", savedCart.getCart_id());
        return savedCart;
    }

    public CompletableFuture<Cart> addToCartAsync(Cart cart) {
        return CompletableFuture.completedFuture(addToCart(cart));
    }

    @CacheEvict(value = "cartItemsCache", allEntries = true)
    public void clearCartCache() {
        logger.debug("Clearing cart items cache.");
    }

    @CacheEvict(value = "cartItemCache", key = "#id")
    public CompletableFuture<Void> removeFromCartAsync(Long id) {
        logger.debug("Removing cart item with ID {}.", id);
        return CompletableFuture.runAsync(() -> {
            Optional<Cart> cartItem = cartRepository.findById(id);
            if (cartItem.isPresent()) {
                cartRepository.deleteById(id);
                logger.info("Cart item with ID {} removed successfully.", id);
            } else {
                logger.warn("Cart item with ID {} not found.", id);
                throw new CartOperationException("Cart item not found for ID: " + id);
            }
        });
    }
}
