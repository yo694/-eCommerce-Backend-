package com.example.ecommerce_product.service;

import com.example.ecommerce_product.entity.User;
import com.example.ecommerce_product.exception.UserAlreadyExistsException;
import com.example.ecommerce_product.exception.UserAuthenticationException;
import com.example.ecommerce_product.exception.UserNotFoundException;
import com.example.ecommerce_product.exception.UserOperationException;
import com.example.ecommerce_product.repository.UserRepository;

import jakarta.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Cacheable(value = "usersCache", key = "'allUsers'")
    public List<User> getAllUsers() {
        logger.debug("Fetching all users.");
        try {
            return userRepository.findAll();
        } catch (Exception e) {
            logger.error("Error occurred while fetching all users: {}", e.getMessage(), e);
            throw new UserOperationException("Error occurred while fetching all users", e);
        }
    }

    @Cacheable(value = "usersCache", key = "#id")
    public User getUserById(Long id) {
        logger.debug("Fetching user with ID {}.", id);
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
    }

    @Async
    @Transactional
    @CacheEvict(value = "usersCache", allEntries = true)
    public User registerUser(User user) {
        logger.debug("Received registration request for user: {}", user.getUsername());
        if (userRepository.findByUsername(user.getUsername()) != null) {
            logger.warn("Registration failed: Username already exists: {}", user.getUsername());
            throw new UserAlreadyExistsException("Username already exists");
        }
        User savedUser = userRepository.save(user);
        logger.info("User registered successfully: {}", user.getUsername());
        return savedUser;
    }

    @Async
    public User authenticateUser(String username, String password) {
        logger.debug("Received login request for username: {}", username);
        User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            logger.info("User authenticated successfully: {}", username);
            return user;
        } else {
            logger.warn("Authentication failed for username: {}", username);
            throw new UserAuthenticationException("Invalid username or password.");
        }
    }
}
