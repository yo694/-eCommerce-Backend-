package com.example.ecommerce_product.controller;

import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce_product.entity.Payment;
import com.example.ecommerce_product.exception.PaymentNotFoundException;
import com.example.ecommerce_product.service.PaymentService;

@RestController
@RequestMapping("api/payments")
public class PaymentController {

    private static final Logger logger = LoggerFactory.getLogger(PaymentController.class);

    @Autowired
    private PaymentService paymentService;

    @PostMapping
    public CompletableFuture<ResponseEntity<Payment>> createPayment(@RequestBody PaymentRequest paymentRequest) {
        logger.debug("Creating payment for order ID {} with amount {}.", paymentRequest.getOrderId(), paymentRequest.getAmount());
        
        if (paymentRequest == null || paymentRequest.getAmount() <= 0) {
            logger.warn("Invalid payment request: {}", paymentRequest);
            return CompletableFuture.completedFuture(ResponseEntity.badRequest().body(null));
        }

        return paymentService.createPayment(paymentRequest.getOrderId(), paymentRequest.getAmount())
                .thenApply(payment -> ResponseEntity.status(HttpStatus.CREATED).body(payment))
                .exceptionally(e -> {
                    logger.error("Failed to create payment: {}", e.getMessage(), e);
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
                });
    }

    @GetMapping("/{id}")
    public CompletableFuture<ResponseEntity<Payment>> getPaymentById(@PathVariable Long id) {
        logger.debug("Fetching payment with ID {}.", id);
        
        return CompletableFuture.supplyAsync(() -> {
            try {
                Payment payment = paymentService.getPaymentById(id);
                return ResponseEntity.ok(payment);
            } catch (PaymentNotFoundException e) {
                logger.warn("Payment not found with ID {}.", id);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            } catch (Exception e) {
                logger.error("Failed to fetch payment with ID {}: {}", id, e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
            }
        });
    }
}

class PaymentRequest {
    private Long orderId;
    private Double amount;

    // Getters and Setters
    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
