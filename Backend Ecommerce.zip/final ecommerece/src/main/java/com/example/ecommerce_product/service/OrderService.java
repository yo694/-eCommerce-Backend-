package com.example.ecommerce_product.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ecommerce_product.entity.Orders;
import com.example.ecommerce_product.exception.OrderNotFoundException;
import com.example.ecommerce_product.repository.OrderRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Async
    @Transactional
    public CompletableFuture<Orders> createOrder(Orders order) {
        if (order == null) {
            throw new IllegalArgumentException("Order cannot be null");
        }
        order.setOrderDate(LocalDateTime.now());
        order.setStatus("Pending");
        Orders savedOrder = orderRepository.save(order);
        return CompletableFuture.completedFuture(savedOrder);
    }

    @Cacheable(value = "ordersCache", key = "'allOrders'")
    public List<Orders> getAllOrders() {
        return orderRepository.findAll();
    }

    @Cacheable(value = "ordersCache", key = "#id")
    public Orders getOrderById(Long id) {
        Orders order = orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + id));
        return order;
    }

    @Async
    @Transactional
    @CachePut(value = "ordersCache", key = "#order.id")
    public CompletableFuture<Orders> updateOrderStatus(Long id, String status) {
        if (status == null || status.isEmpty()) {
            throw new IllegalArgumentException("Status cannot be null or empty");
        }

        Orders order = orderRepository.findById(id)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with ID: " + id));
        
        order.setStatus(status);
        Orders updatedOrder = orderRepository.save(order);
        return CompletableFuture.completedFuture(updatedOrder);
    }

    @CacheEvict(value = "ordersCache", allEntries = true)
    public void clearOrdersCache() {
        // This method will be used to clear all entries in the ordersCache
    }
}
