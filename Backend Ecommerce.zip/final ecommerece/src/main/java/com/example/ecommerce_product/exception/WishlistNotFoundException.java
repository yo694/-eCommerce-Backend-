package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class WishlistNotFoundException extends RuntimeException {
    public WishlistNotFoundException(String message) {
        super(message);
    }
}
