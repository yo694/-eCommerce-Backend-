package com.example.ecommerce_product.config;

import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import javax.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.net.URI;
import java.net.URISyntaxException;
import java.io.IOException;

@Configuration
@EnableCaching
public class CacheConfig {

    @Bean
    public JCacheCacheManager cacheManager() throws IOException, URISyntaxException {
        // Obtain the caching provider
        CachingProvider cachingProvider = Caching.getCachingProvider();
        
        // Load the cache configuration from the ehcache.xml file
        URI configUri = getClass().getClassLoader().getResource("ehcache.xml").toURI();
        CacheManager jCacheManager = cachingProvider.getCacheManager(configUri, getClass().getClassLoader());
        
        // Create and return a JCacheCacheManager using the JCache CacheManager
        return new JCacheCacheManager(jCacheManager);
    }
}
