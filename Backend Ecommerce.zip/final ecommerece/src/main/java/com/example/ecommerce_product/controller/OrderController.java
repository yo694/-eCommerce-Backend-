package com.example.ecommerce_product.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce_product.entity.Orders;
import com.example.ecommerce_product.service.OrderService;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    @Autowired
    private OrderService orderService;

    @PostMapping
    public CompletableFuture<ResponseEntity<Orders>> createOrder(@RequestBody Orders order) {
        logger.debug("Creating order: {}", order);
        return orderService.createOrder(order)
            .thenApply(createdOrder -> {
                logger.info("Order created successfully: {}", createdOrder);
                return ResponseEntity.status(HttpStatus.CREATED).body(createdOrder);
            })
            .exceptionally(e -> {
                logger.error("Failed to create order: {}", e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
            });
    }

    @GetMapping
    public ResponseEntity<List<Orders>> getAllOrders() {
        logger.debug("Fetching all orders.");
        List<Orders> orders = orderService.getAllOrders();  // Directly retrieve the list
        if (orders.isEmpty()) {
            logger.info("No orders found.");
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(orders);
        }
        logger.info("Orders fetched successfully.");
        return ResponseEntity.ok(orders);
    }
}
