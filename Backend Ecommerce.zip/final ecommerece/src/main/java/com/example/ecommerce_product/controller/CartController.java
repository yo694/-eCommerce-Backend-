package com.example.ecommerce_product.controller;
import java.util.concurrent.CompletableFuture;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.ecommerce_product.entity.Cart;
import com.example.ecommerce_product.service.CartService;
import com.example.ecommerce_product.service.ProductService;
@RestController
@RequestMapping("/api/cart")
public class CartController {
    private static final Logger logger = LoggerFactory.getLogger(CartController.class);
    @Autowired
    private CartService cartService;
    @Autowired
    private ProductService productService;

    @GetMapping
    public CompletableFuture<ResponseEntity<?>> getAllCartItems() {
        logger.debug("Fetching all cart items.");
        return cartService.getAllCartItemsAsync()
                .thenApply(cartItems -> {
                    if (cartItems.isEmpty()) {
                        logger.info("No cart items found.");
                        return ResponseEntity.noContent().build();
                    } else {
                        logger.info("Retrieved {} cart items.", cartItems.size());
                        return ResponseEntity.ok(cartItems);
                    }
                })
                .exceptionally(e -> {
                    logger.error("Error occurred while fetching cart items: {}", e.getMessage());
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                });
    }

    @PostMapping
    public CompletableFuture<ResponseEntity<?>> addToCart(@RequestParam Long productId, @RequestParam int quantity) {
        logger.debug("Adding product with ID {} to cart with quantity {}.", productId, quantity);
        
        if (quantity <= 0) {
            logger.warn("Invalid quantity: {}", quantity);
            return CompletableFuture.completedFuture(ResponseEntity.badRequest().build());
        }

        return productService.getProductById(productId)
                .thenCompose(product -> {
                    if (product != null) {
                        Cart cart = new Cart();
                        cart.setProduct(product);
                        cart.setQuantity(quantity);
                        return cartService.addToCartAsync(cart)
                                .thenApply(savedCart -> {
                                    logger.info("Product added to cart successfully. Cart ID: {}", savedCart.getCart_id());
                                    return ResponseEntity.status(HttpStatus.CREATED).body(savedCart);
                                });
                    } else {
                        logger.warn("Product with ID {} not found.", productId);
                        return CompletableFuture.completedFuture(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
                    }
                })
                .exceptionally(e -> {
                    logger.error("Error occurred while adding product to cart: {}", e.getMessage());
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                });
    }

    @DeleteMapping("/{id}")
    public CompletableFuture<ResponseEntity<Object>> removeFromCart(@PathVariable Long id) {
        logger.debug("Removing cart item with ID {}.", id);
        return cartService.removeFromCartAsync(id)
                .thenApply(aVoid -> {
                    logger.info("Cart item with ID {} removed successfully.", id);
                    return ResponseEntity.noContent().build();
                })
                .exceptionally(e -> {
                    logger.error("Error occurred while removing cart item with ID {}: {}", id, e.getMessage());
                    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
                });
    }
}
