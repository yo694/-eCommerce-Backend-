package com.example.ecommerce_product.exception;

@SuppressWarnings("serial")
public class PaymentNotFoundException extends RuntimeException {
    public PaymentNotFoundException(String message) {
        super(message);
    }
}
