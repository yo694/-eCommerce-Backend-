package com.example.ecommerce_product.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.ecommerce_product.entity.Product;
import com.example.ecommerce_product.exception.InvalidProductException;
import com.example.ecommerce_product.exception.ProductNotFoundException;
import com.example.ecommerce_product.service.ProductService;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private ProductService productService;

    @GetMapping
    public CompletableFuture<ResponseEntity<List<Product>>> getAllProducts() {
        logger.debug("Fetching all products.");
        return CompletableFuture.supplyAsync(() -> {
            try {
                List<Product> products = productService.getAllProducts();
                if (products.isEmpty()) {
                    logger.info("No products found.");
                    return ResponseEntity.noContent().build();
                }
                return ResponseEntity.ok(products);
            } catch (Exception e) {
                logger.error("Error occurred while fetching products: {}", e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        });
    }

    @GetMapping("/{id}")
    public CompletableFuture<ResponseEntity<? extends Object>> getProductById(@PathVariable Long id) {
        logger.debug("Fetching product with ID {}.", id);
        return CompletableFuture.supplyAsync(() -> {
            try {
                CompletableFuture<Product> product = productService.getProductById(id);
                return ResponseEntity.ok(product);
            } catch (ProductNotFoundException e) {
                logger.warn("Product with ID {} not found: {}", id, e.getMessage());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            } catch (Exception e) {
                logger.error("Error occurred while fetching product with ID {}: {}", id, e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
            }
        });
    }

    @PostMapping
    public CompletableFuture<ResponseEntity<? extends Object>> createProduct(@RequestBody Product product) {
        logger.debug("Creating product: {}", product);
        return CompletableFuture.supplyAsync(() -> {
            try {
                validateProduct(product);
                CompletableFuture<Product> createdProduct = productService.addProduct(product);
                return ResponseEntity.status(HttpStatus.CREATED).body(createdProduct);
            } catch (InvalidProductException e) {
                logger.warn("Invalid product details: {}", e.getMessage());
                return ResponseEntity.badRequest().body(null);
            } catch (Exception e) {
                logger.error("Error occurred while creating product: {}", e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
            }
        });
    }

    @PutMapping("/{id}")
    public CompletableFuture<ResponseEntity<? extends Object>> updateProduct(@PathVariable Long id, @RequestBody Product product) {
        logger.debug("Updating product with ID {}: {}", id, product);
        return CompletableFuture.supplyAsync(() -> {
            try {
                validateProduct(product);
                CompletableFuture<Product> updatedProduct = productService.updateProduct(id, product);
                return ResponseEntity.ok(updatedProduct);
            } catch (InvalidProductException e) {
                logger.warn("Invalid product details: {}", e.getMessage());
                return ResponseEntity.badRequest().body(null);
            } catch (ProductNotFoundException e) {
                logger.warn("Product with ID {} not found: {}", id, e.getMessage());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            } catch (Exception e) {
                logger.error("Error occurred while updating product with ID {}: {}", id, e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
            }
        });
    }

    @DeleteMapping("/{id}")
    public CompletableFuture<ResponseEntity<Void>> deleteProduct(@PathVariable Long id) {
        logger.debug("Deleting product with ID {}.", id);
        return CompletableFuture.supplyAsync(() -> {
            try {
                productService.deleteProduct(id);
                return ResponseEntity.noContent().build();
            } catch (ProductNotFoundException e) {
                logger.warn("Product with ID {} not found: {}", id, e.getMessage());
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            } catch (Exception e) {
                logger.error("Error occurred while deleting product with ID {}: {}", id, e.getMessage(), e);
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
            }
        });
    }

    private void validateProduct(Product product) {
        if (product == null || product.getProduct_name() == null || product.getProduct_name().isEmpty()) {
            throw new InvalidProductException("Product name cannot be null or empty");
        }
        if (product.getProduct_price() <= 0) {
            throw new InvalidProductException("Product price must be greater than zero");
        }
        if (product.getProduct_quantity() < 0) {
            throw new InvalidProductException("Product quantity cannot be negative");
        }
    }
}
