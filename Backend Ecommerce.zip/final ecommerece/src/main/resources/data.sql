-- Insert Users
INSERT INTO user_cred (username, password) VALUES 
('john_doe', 'password123'),
('jane_smith', 'securepassword'),
('alice_jones', 'mypassword');

-- Insert Products
INSERT INTO product (product_name, product_price, product_special_price, product_quantity, product_discount, product_image, description, product_category, created_date, updated_date) VALUES 
('Laptop', 999.99, 899.99, 10, 10.0, 'laptop.jpg', 'A high-performance laptop.', 'Electronics', NOW(), NOW()),
('Smartphone', 499.99, 449.99, 20, 5.0, 'smartphone.jpg', 'A latest smartphone with all features.', 'Electronics', NOW(), NOW()),
('Headphones', 79.99, 69.99, 30, 10.0, 'headphones.jpg', 'Noise-cancelling headphones.', 'Accessories', NOW(), NOW()),
('Keyboard', 49.99, 39.99, 50, 15.0, 'keyboard.jpg', 'Mechanical keyboard.', 'Accessories', NOW(), NOW()),
('Mouse', 29.99, 24.99, 100, 20.0, 'mouse.jpg', 'Wireless mouse.', 'Accessories', NOW(), NOW());

-- Insert Wishlist Categories
INSERT INTO wishlist_category (category_name) VALUES 
('Electronics'),
('Accessories'),
('Home Appliances');

-- Insert Wishlist Items
INSERT INTO wishlist_item (user_id, product_id, category_id) VALUES 
(1, 1, 1),  -- John Doe wants Laptop in Electronics
(1, 3, 2),  -- John Doe wants Headphones in Accessories
(2, 2, 1),  -- Jane Smith wants Smartphone in Electronics
(3, 4, 3);  -- Alice Jones wants Keyboard in Home Appliances

-- Insert Cart Items
INSERT INTO cart (product_id, quantity) VALUES 
(1, 1),   -- Add 1 Laptop to cart
(2, 2);   -- Add 2 Smartphones to cart

-- Insert Orders
INSERT INTO orders (product_id, quantity, order_date, status) VALUES 
(1, 1, NOW(), 'Shipped'),
(2, 2, NOW(), 'Processing'),
(4, 1, NOW(), 'Delivered');

-- Insert Payments
INSERT INTO payments (order_id, amount, payment_date, status) VALUES 
(1, 999.99, NOW(), 'Completed'),
(2, 999.98, NOW(), 'Pending'),
(3, 49.99, NOW(), 'Completed');
